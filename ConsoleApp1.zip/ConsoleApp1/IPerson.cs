﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public interface IPerson
    {
        //データの形式はIPersonという型だけをIF継承させておき、拡張に対応?
    }
}
